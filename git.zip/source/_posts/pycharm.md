---
title: pycharm插件
date: 2018-06-12 19:03:38
tags:
    编程开发
---
## pycharm插件使用
打开`file->setting->plugins` 是pycharm的插件界面了 自带的插件比较多 包括了`git`,`ssh`,`javascript`,`css`等

pycharm也提供了从官方存储库下载的功能，只需点击`install jetbrain plugins`. 从磁盘下载则是`install plugins for disk`

## 常用插件推荐
`.ignore` 版本控制库忽略提交文件 如`git`的`.gitignore` 插件

`markdown support` markdown插件

` Material Theme ui` pycharm主题 非常好看

`ideavim`  vim操作支持
`statistic`  统计项目行数


